#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h> 
#include <stdlib.h> 
#include "funkcije.h"
#include "Header.h"

int izbornik(const char* const vozaci) {
	printf("====================");
	printf("Odaberite jednu od ponudenih opcija:");
	printf("====================\n");
	printf("\t\t\tOpcija 1: kreiranje datoteke!\n");
	printf("\t\t\tOpcija 2: dodavanje vozaca!\n");
	printf("\t\t\tOpcija 3: ucitavanje vozaca!\n");
	printf("\t\t\tOpcija 4: ispisivanje vozaca!\n");
	printf("\t\t\tOpcija 5: pretrazivanje vozaca!\n");
	printf("\t\t\tOpcija 6: brisanje vozaca!\n");
	printf("\t\t\tOpcija 7: izlaz iz programa!\n");
	printf("====================\n");

	int uvjet = 0;
	static VOZAC* poljeVozaca = NULL;
	static VOZAC* pronadeniVozac = NULL;
	scanf("%d", &uvjet);

	switch (uvjet) {
	case 1:
		kreiranjeDatoteke("vozaci.bin");
		break;
	case 2:
		dodajVozaca("vozaci.bin");
		break;
	case 3:
		if (poljeVozaca == NULL) {
			free(poljeVozaca);
			poljeVozaca == NULL;
		}
		poljeVozaca = (VOZAC*)ucitavanjeVozaca("vozaci.bin");
		if (poljeVozaca == NULL) {
			exit(EXIT_FAILURE);
		}
		break;
	case 4:
		ispisivanjeVozaca(poljeVozaca);
		break;

	default:
		uvjet = 0;
	}



	return uvjet;
}