#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "funkcije.h"

int main() {

	int uvjet = 1;
	while (uvjet) { 
		uvjet = izbornik("vozaci.bin");
	}

	printf("Zavrsetak programa!\n");

 return 0;
}