#ifndef FUNKCIJE_H 
#define FUNKCIJE_H  
#include "header.h" 


int izbornik(const char* const);
void kreiranjeDatoteke(const char* const);
void dodajVozaca(const char* const);


#endif //FUNKCIJE_H
