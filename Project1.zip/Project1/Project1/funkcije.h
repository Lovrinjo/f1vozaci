#ifndef FUNKCIJE_H 
#define FUNKCIJE_H  
#include "header.h" 


int izbornik(const char* const);
void kreiranjeDatoteke(const char* const);
void dodajVozaca(const char* const);
void* ucitavanjeVozaca(const char* const);
void ispisivanjeVozaca(const VOZAC* const);

#endif //FUNKCIJE_H
