#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include "header.h"


static int brojVozaca = 0;

void kreiranjeDatoteke(const char* const imeDatoteke) {
	FILE* pF = fopen("vozaci.bin", "wb");
	if (pF == NULL) {
		perror("Kreiranje datoteke vozaci.bin");
		exit(EXIT_FAILURE);
	}
	fwrite(&brojVozaca, sizeof(int), 1, pF);  
	fclose(pF);
}

void dodajVozaca(const char* const imeDatoteke) {

	FILE* pF = fopen("vozaci.bin", "rb+");
	if (pF == NULL) {
		perror("Dodavanje vozaca u datoteke vozaci.bin");
		exit(EXIT_FAILURE);
	}
	fread(&brojVozaca, sizeof(int), 1, pF);
	printf("brojVozaca: %d\n", brojVozaca);
	VOZAC temp = { 0 };
	temp.id = brojVozaca;
	getchar();
	printf("Unesite ime Vozaca!\n");
	scanf("%19[^\n]", temp.ime);
	printf("Unesite prezime Vozaca!\n");
	getchar();
	scanf("%19[^\n]", temp.prezime);
	fseek(pF, sizeof(VOZAC) * brojVozaca, SEEK_CUR);
	fwrite(&temp, sizeof(VOZAC), 1, pF);
	rewind(pF);
	brojVozaca++;
	fwrite(&brojVozaca, sizeof(int), 1, pF);
	fclose(pF);
}