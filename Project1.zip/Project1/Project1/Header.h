#ifndef DATATYPE_H 
#define DATATYPE_H  
typedef struct vozac {  
	int id;  
	char ime[20];  
	char prezime[20];
	char drzavljanstvo[20];
	int pobjede;
	int podij;
	int bodovi;
	int utrke;
}VOZAC;  
#endif //DATATYPE_H
