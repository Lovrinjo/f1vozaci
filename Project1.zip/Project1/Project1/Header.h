#ifndef DATATYPE_H 
#define DATATYPE_H  
typedef struct vozac {  
	int id;  
	char ime[20];  
	char prezime[20];
	int pobjede;
	int podij;
	int bodovi;
	int utrke;
	char drzavljanstvo[20];
}VOZAC;  
#endif //DATATYPE_H
